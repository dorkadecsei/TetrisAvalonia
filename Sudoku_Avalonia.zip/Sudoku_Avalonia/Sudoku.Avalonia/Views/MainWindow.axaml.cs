﻿using Avalonia.Controls;

namespace ELTE.Sudoku.Avalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
