﻿using Avalonia.Controls;

namespace ELTE.Sudoku.Avalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
