﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace ELTE.Sudoku.Avalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
