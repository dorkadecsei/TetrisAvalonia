﻿using System.Windows;
using TetrisWPF.ViewModel;

namespace TetrisWPF.View
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}